"""
FastAPI application for the Interview Chatbot.
Provides REST API endpoints for session management and chat.
"""
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from langchain_core.messages import HumanMessage
from models.schemas import (
    InterviewSessionCreate,
    InterviewSessionResponse,
    ChatRequest,
    ChatResponse
)
from database import crud
from ai_agents.graph import interview_graph
from ai_agents.state import InterviewState
from config import Config
import uvicorn


# Initialize FastAPI app
app = FastAPI(
    title="Interview Chatbot API",
    description="LLM-powered interview chatbot with role-specific questioning",
    version="1.0.0"
)

# Configure CORS for Streamlit frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, specify exact origins
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/")
async def root():
    """Health check endpoint."""
    return {
        "status": "healthy",
        "message": "Interview Chatbot API is running",
        "version": "1.0.0"
    }


@app.post("/api/session/create", response_model=InterviewSessionResponse)
async def create_session(session_data: InterviewSessionCreate):
    """
    Create a new interview session.
    
    Args:
        session_data: Session creation data (username, role, description)
        
    Returns:
        InterviewSessionResponse: Created session details
    """
    try:
        print(f"📝 Creating session for {session_data.username} - Role: {session_data.role}")
        
        # Create session in database
        session_id = crud.create_interview_session(
            username=session_data.username,
            role=session_data.role,
            description=session_data.description
        )
        print(f"✅ Session created with ID: {session_id}")
        
        # Retrieve created session
        session = crud.get_interview_session(session_id)
        
        if not session:
            raise HTTPException(status_code=500, detail="Failed to create session")
        
        print(f"🤖 Generating initial greeting from LLM...")
        
        # Generate initial greeting message from LLM
        state: InterviewState = {
            "messages": [],
            "session_id": session_id,
            "username": session_data.username,
            "role": session_data.role,
            "description": session_data.description,
            "question_count": 0,
            "max_questions": Config.MAX_INTERVIEW_QUESTIONS,
            "interview_active": True
        }
        
        try:
            # Run the interview graph to get initial greeting
            result = interview_graph.invoke(state)
            
            # Extract and save the greeting message
            greeting_message = result['messages'][-1]
            crud.save_message(
                session_id=session_id,
                role="assistant",
                content=greeting_message.content
            )
            print(f"✅ Initial greeting generated and saved")
            
        except Exception as llm_error:
            print(f"❌ Error generating greeting: {str(llm_error)}")
            print(f"Full error: {repr(llm_error)}")
            raise
        
        return InterviewSessionResponse(**session)
    
    except Exception as e:
        print(f"❌ Error creating session: {str(e)}")
        print(f"Full error: {repr(e)}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"Error creating session: {str(e)}")


@app.get("/api/session/{session_id}", response_model=InterviewSessionResponse)
async def get_session(session_id: str):
    """
    Retrieve an interview session by ID.
    
    Args:
        session_id: Session identifier
        
    Returns:
        InterviewSessionResponse: Session details
    """
    session = crud.get_interview_session(session_id)
    
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    
    return InterviewSessionResponse(**session)


@app.get("/api/session/{session_id}/history")
async def get_history(session_id: str):
    """
    Retrieve conversation history for a session.
    
    Args:
        session_id: Session identifier
        
    Returns:
        list: Conversation history
    """
    session = crud.get_interview_session(session_id)
    
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    
    history = crud.get_conversation_history(session_id)
    return history


@app.post("/api/chat", response_model=ChatResponse)
async def chat(chat_request: ChatRequest):
    """
    Send a message and get LLM response.
    
    Args:
        chat_request: Chat request with session_id and message
        
    Returns:
        ChatResponse: LLM response and session status
    """
    try:
        print(f"\n💬 Received message: {chat_request.message[:50]}...")
        
        # Verify session exists
        session = crud.get_interview_session(chat_request.session_id)
        if not session:
            raise HTTPException(status_code=404, detail="Session not found")
        
        print(f"✅ Session found: {session['username']} - {session['role']}")
        
        # Check if user wants to exit early
        exit_keywords = ['emergency', 'need to leave', 'have to go', 'need to run', 'gotta go', 'must leave', 'cant continue', "can't continue"]
        user_wants_exit = any(keyword in chat_request.message.lower() for keyword in exit_keywords)
        
        if user_wants_exit:
            print(f"⚠️ Early exit detected in user message")
        
        # Save user message to database
        crud.save_message(
            session_id=chat_request.session_id,
            role="user",
            content=chat_request.message
        )
        
        # Get conversation history
        history = crud.get_conversation_history(chat_request.session_id)
        print(f"📚 Loaded {len(history)} messages from history")
        
        # Convert history to LangChain messages
        messages = []
        for msg in history:
            if msg['role'] == 'user':
                messages.append(HumanMessage(content=msg['content']))
            # Assistant messages will be added by the graph
        
        # Prepare state for LangGraph
        state: InterviewState = {
            "messages": messages,
            "session_id": chat_request.session_id,
            "username": session['username'],
            "role": session['role'],
            "description": session['description'],
            "question_count": crud.get_question_count(chat_request.session_id),
            "max_questions": Config.MAX_INTERVIEW_QUESTIONS,
            "interview_active": session['status'] == 'active'
        }
        
        print(f"🤖 Invoking LLM (Question count: {state['question_count']}/{state['max_questions']})")
        
        # Run the interview graph
        result = interview_graph.invoke(state)
        
        # Extract assistant response
        assistant_message = result['messages'][-1]
        response_content = assistant_message.content
        
        print(f"✅ LLM response generated ({len(response_content)} chars)")
        
        # Save assistant response to database
        crud.save_message(
            session_id=chat_request.session_id,
            role="assistant",
            content=response_content
        )
        
        # Update question count
        question_count = crud.get_question_count(chat_request.session_id)
        
        # Update session status based on conditions
        if user_wants_exit:
            # User requested early exit
            crud.update_session_status(chat_request.session_id, "terminated")
            interview_active = False
            print(f"🚪 Interview terminated early by user request")
        elif question_count >= Config.MAX_INTERVIEW_QUESTIONS:
            # Reached maximum questions
            crud.update_session_status(chat_request.session_id, "completed")
            interview_active = False
            print(f"🏁 Interview completed ({question_count} questions)")
        else:
            interview_active = True
        
        return ChatResponse(
            session_id=chat_request.session_id,
            response=response_content,
            question_count=question_count,
            interview_active=interview_active
        )
    
    except HTTPException:
        raise
    except Exception as e:
        print(f"❌ Error processing chat: {str(e)}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"Error processing chat: {str(e)}")


if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host=Config.API_HOST,
        port=Config.API_PORT,
        reload=True
    )
