"""
Pydantic models for request/response validation.
"""
from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime


class InterviewSessionCreate(BaseModel):
    """Request model for creating a new interview session."""
    username: str = Field(..., min_length=1, description="Name of the interviewee")
    role: str = Field(..., min_length=1, description="Role being interviewed for")
    description: str = Field(default="", description="Brief description of the interview")


class InterviewSessionResponse(BaseModel):
    """Response model for interview session data."""
    session_id: str
    username: str
    role: str
    description: str
    status: str
    created_at: str


class ChatMessage(BaseModel):
    """Model for a single chat message."""
    role: str = Field(..., pattern="^(user|assistant)$", description="Message role")
    content: str = Field(..., min_length=1, description="Message content")
    timestamp: Optional[str] = None


class ChatRequest(BaseModel):
    """Request model for chat endpoint."""
    session_id: str = Field(..., description="Session identifier")
    message: str = Field(..., min_length=1, description="User message")


class ChatResponse(BaseModel):
    """Response model for chat endpoint."""
    session_id: str
    response: str
    question_count: int
    interview_active: bool
