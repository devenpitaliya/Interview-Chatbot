"""Backend package initialization."""
