"""
CRUD operations for database interactions.
Handles interview sessions and conversation history.
"""
import uuid
from datetime import datetime
from typing import List, Optional, Dict, Any
from database.db import get_db_connection


def create_interview_session(username: str, role: str, description: str) -> str:
    """
    Create a new interview session.
    
    Args:
        username: Name of the interviewee
        role: Role being interviewed for
        description: Brief description of the interview
        
    Returns:
        str: Generated session ID
    """
    session_id = str(uuid.uuid4())
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute("""
        INSERT INTO interview_sessions (session_id, username, role, description, status)
        VALUES (?, ?, ?, ?, 'active')
    """, (session_id, username, role, description))
    
    conn.commit()
    conn.close()
    
    return session_id


def get_interview_session(session_id: str) -> Optional[Dict[str, Any]]:
    """
    Retrieve an interview session by ID.
    
    Args:
        session_id: Session identifier
        
    Returns:
        Optional[Dict]: Session data or None if not found
    """
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute("""
        SELECT * FROM interview_sessions WHERE session_id = ?
    """, (session_id,))
    
    row = cursor.fetchone()
    conn.close()
    
    if row:
        return dict(row)
    return None


def update_session_status(session_id: str, status: str) -> None:
    """
    Update the status of an interview session.
    
    Args:
        session_id: Session identifier
        status: New status ('active', 'completed', 'terminated')
    """
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute("""
        UPDATE interview_sessions 
        SET status = ?, updated_at = CURRENT_TIMESTAMP
        WHERE session_id = ?
    """, (status, session_id))
    
    conn.commit()
    conn.close()


def save_message(session_id: str, role: str, content: str) -> None:
    """
    Save a message to conversation history.
    
    Args:
        session_id: Session identifier
        role: Message role ('user' or 'assistant')
        content: Message content
    """
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute("""
        INSERT INTO conversation_history (session_id, role, content)
        VALUES (?, ?, ?)
    """, (session_id, role, content))
    
    conn.commit()
    conn.close()


def get_conversation_history(session_id: str) -> List[Dict[str, Any]]:
    """
    Retrieve conversation history for a session.
    
    Args:
        session_id: Session identifier
        
    Returns:
        List[Dict]: List of messages with role and content
    """
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute("""
        SELECT role, content, timestamp 
        FROM conversation_history 
        WHERE session_id = ?
        ORDER BY timestamp ASC
    """, (session_id,))
    
    rows = cursor.fetchall()
    conn.close()
    
    return [dict(row) for row in rows]


def get_question_count(session_id: str) -> int:
    """
    Count the number of questions asked by the assistant.
    
    Args:
        session_id: Session identifier
        
    Returns:
        int: Number of assistant messages (questions)
    """
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute("""
        SELECT COUNT(*) as count
        FROM conversation_history 
        WHERE session_id = ? AND role = 'assistant'
    """, (session_id,))
    
    result = cursor.fetchone()
    conn.close()
    
    return result['count'] if result else 0
