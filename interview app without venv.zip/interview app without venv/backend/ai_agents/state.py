"""
State management for LangGraph interview workflow.
"""
from typing import TypedDict, List, Annotated
from langchain_core.messages import BaseMessage
from langgraph.graph.message import add_messages


class InterviewState(TypedDict):
    """
    State object for the interview conversation graph.
    
    Attributes:
        messages: List of conversation messages
        session_id: Unique identifier for the interview session
        username: Name of the interviewee
        role: Role being interviewed for
        description: Brief description of the interview
        question_count: Number of questions asked so far
        max_questions: Maximum number of questions to ask
        interview_active: Whether the interview is still ongoing
    """
    messages: Annotated[List[BaseMessage], add_messages]
    session_id: str
    username: str
    role: str
    description: str
    question_count: int
    max_questions: int
    interview_active: bool
