"""AI agents package initialization."""
