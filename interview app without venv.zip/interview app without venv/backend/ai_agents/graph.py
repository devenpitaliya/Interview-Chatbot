"""
LangGraph workflow definition for the interview chatbot.
Creates a simple graph that routes between interviewer and tools.
"""
from langgraph.graph import StateGraph, END
from langgraph.prebuilt import ToolNode
from ai_agents.state import InterviewState
from ai_agents.nodes import interviewer_node
from tools.interview_tools import interview_tools


def should_continue(state: InterviewState) -> str:
    """
    Determine if the conversation should continue or end.
    
    Args:
        state: Current interview state
        
    Returns:
        str: Next node to execute ("tools" or "end")
    """
    messages = state['messages']
    last_message = messages[-1]
    
    # If the LLM made tool calls, execute them
    if hasattr(last_message, 'tool_calls') and last_message.tool_calls:
        return "tools"
    
    # Otherwise, end this turn
    return "end"


def create_interview_graph() -> StateGraph:
    """
    Create the LangGraph workflow for the interview.
    
    Returns:
        StateGraph: Compiled interview graph
    """
    # Initialize the graph
    workflow = StateGraph(InterviewState)
    
    # Add nodes
    workflow.add_node("interviewer", interviewer_node)
    workflow.add_node("tools", ToolNode(interview_tools))
    
    # Set entry point
    workflow.set_entry_point("interviewer")
    
    # Add conditional edges
    workflow.add_conditional_edges(
        "interviewer",
        should_continue,
        {
            "tools": "tools",
            "end": END
        }
    )
    
    # After tools, go back to interviewer
    workflow.add_edge("tools", "interviewer")
    
    # Compile the graph
    graph = workflow.compile()
    
    return graph


# Create the graph instance
interview_graph = create_interview_graph()
