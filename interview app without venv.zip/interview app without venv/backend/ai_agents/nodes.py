"""
LangGraph nodes for the interview workflow.
Contains the main interviewer logic powered by LLM.
"""
from langchain_core.messages import HumanMessage, SystemMessage, AIMessage
from langchain_groq import ChatGroq
from langgraph.prebuilt import ToolNode
from ai_agents.state import InterviewState
from tools.interview_tools import interview_tools
from config import Config
from database import crud


def create_interviewer_llm():
    """
    Create and configure the LLM for the interviewer.
    
    Returns:
        ChatGroq: Configured LLM with tools bound
    """
    llm = ChatGroq(
        model=Config.GROQ_MODEL,
        temperature=Config.MODEL_TEMPERATURE,
        api_key=Config.GROQ_API_KEY
    )
    
    # Bind tools to the LLM
    llm_with_tools = llm.bind_tools(interview_tools)
    
    return llm_with_tools


def create_system_prompt(state: InterviewState) -> str:
    """
    Create a comprehensive system prompt for the interviewer.
    
    Args:
        state: Current interview state
        
    Returns:
        str: System prompt for the LLM
    """
    current_count = state['question_count']
    max_questions = state['max_questions']
    remaining = max_questions - current_count
    
    # Determine if this is the last question
    is_last_question = remaining == 1
    is_closing = remaining == 0
    
    if is_closing:
        return f"""You are a professional and friendly interviewer who has just completed an interview with {state['username']} for the role of {state['role']}.

**IMPORTANT**: You have already asked all {max_questions} questions. DO NOT ask any more questions.

Your task now is to:
1. Thank {state['username']} warmly for their time and thoughtful responses
2. Acknowledge their skills and experience positively
3. Let them know the team will review their responses and get back to them soon
4. End on an encouraging and professional note

Be genuine, warm, and professional. Make them feel valued and appreciated."""

    base_prompt = f"""You are a professional and friendly interviewer conducting a job interview for the role of {state['role']}.

**Interview Context:**
- Candidate Name: {state['username']}
- Role: {state['role']}
- Interview Description: {state['description']}
- Questions Asked So Far: {current_count}
- Maximum Questions: {max_questions}
- Remaining Questions: {remaining}

**Your Responsibilities:**
1. Conduct a natural, conversational interview that feels human and engaging
2. Ask role-specific technical and behavioral questions appropriate for {state['role']}
3. Listen carefully to candidate responses and ask relevant follow-up questions
4. Track the number of questions you've asked using the check_question_count tool
5. {"**THIS IS YOUR LAST QUESTION** - After this response, you must close the interview warmly" if is_last_question else f"Ask thoughtful questions (you have {remaining} questions remaining)"}

**Conversation Guidelines:**
- **Natural Tone**: Speak like a human interviewer, not a robot. Be warm, professional, and encouraging
- **Greetings**: Start with a friendly greeting using the candidate's name. Handle casual greetings (hi, hello) naturally
- **Question Quality**: Ask thoughtful, role-specific questions. Vary between technical skills, experience, problem-solving, and behavioral questions
- **Clarification**: If the candidate says they don't understand a question, rephrase it in simpler terms without being condescending
- **Off-Topic Handling**: If the candidate goes off-topic, politely acknowledge and gently redirect to the interview
- **Early Exit - CRITICAL**: If the candidate mentions they need to leave, have an emergency, can't continue, or want to stop the interview:
  1. Immediately express understanding and concern
  2. Tell them to take care of themselves/their situation
  3. Thank them for their time so far
  4. Let them know the team will be in touch
  5. **DO NOT** ask any follow-up questions or try to continue the interview
  6. **DO NOT** interpret their next response as wanting to continue - treat it as a final goodbye
  7. End with a warm, brief closing statement

**Important Rules:**
- Do NOT ask all questions at once - this is a conversation, not a questionnaire
- Do NOT sound robotic or use template-like language
- Do NOT be overly formal - maintain professional friendliness
- {"**CRITICAL**: This is your FINAL QUESTION. After the candidate responds, you MUST close the interview warmly without asking another question" if is_last_question else f"DO NOT continue past {max_questions} questions"}
- **CRITICAL**: If candidate wants to leave early, END THE INTERVIEW IMMEDIATELY - do not continue or ask more questions
- DO use the check_question_count tool regularly to track your progress
- DO make the candidate feel comfortable and valued

**Interview Flow:**
"""
    
    # Add interview flow based on state
    if is_last_question:
        base_prompt += """1. This is your LAST question - make it count
2. After their response, close the interview warmly
3. Thank them, acknowledge their skills, and let them know you'll get back to them

Remember: You're having a professional conversation with a real person. Be human, be kind, and make this a positive experience."""
    else:
        base_prompt += """1. Ask questions one at a time, waiting for responses
2. Show genuine interest in their answers
3. Ask follow-up questions when appropriate

Remember: You're having a professional conversation with a real person. Be human, be kind, and make this a positive experience."""
    
    return base_prompt


def interviewer_node(state: InterviewState) -> InterviewState:
    """
    Main interviewer node that generates responses using LLM.
    
    Args:
        state: Current interview state
        
    Returns:
        InterviewState: Updated state with new message
    """
    # Create LLM with tools
    llm = create_interviewer_llm()
    
    # Get current question count
    question_count = crud.get_question_count(state['session_id'])
    state['question_count'] = question_count
    
    # Check if interview should end
    if question_count >= state['max_questions']:
        state['interview_active'] = False
    
    # Create system prompt
    system_prompt = create_system_prompt(state)
    
    # Prepare messages for LLM
    messages = [SystemMessage(content=system_prompt)] + state['messages']
    
    # Get LLM response
    response = llm.invoke(messages)
    
    # Update state with response
    state['messages'].append(response)
    
    return state


def tool_node(state: InterviewState) -> InterviewState:
    """
    Node for executing tool calls made by the LLM.
    
    Args:
        state: Current interview state
        
    Returns:
        InterviewState: Updated state after tool execution
    """
    tool_executor = ToolNode(interview_tools)
    return tool_executor(state)
