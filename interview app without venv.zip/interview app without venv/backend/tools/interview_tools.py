"""
LLM-accessible tools for interview management.
These tools allow the LLM to check conversation state and make decisions.
"""
from langchain_core.tools import tool
from typing import Dict, Any
from database import crud
from config import Config


@tool
def get_conversation_history(session_id: str) -> str:
    """
    Retrieve the conversation history for the current interview session.
    Use this to understand the context of the conversation.
    
    Args:
        session_id: The interview session identifier
        
    Returns:
        str: Formatted conversation history
    """
    history = crud.get_conversation_history(session_id)
    
    if not history:
        return "No conversation history yet."
    
    formatted = []
    for msg in history:
        role = "Interviewer" if msg['role'] == 'assistant' else "Candidate"
        formatted.append(f"{role}: {msg['content']}")
    
    return "\n".join(formatted)


@tool
def check_question_count(session_id: str) -> Dict[str, Any]:
    """
    Check how many questions have been asked in this interview.
    Use this to track progress and determine if the interview should end.
    
    Args:
        session_id: The interview session identifier
        
    Returns:
        dict: Question count and maximum allowed questions
    """
    count = crud.get_question_count(session_id)
    max_questions = Config.MAX_INTERVIEW_QUESTIONS
    
    return {
        "questions_asked": count,
        "max_questions": max_questions,
        "remaining": max_questions - count,
        "should_end": count >= max_questions
    }


@tool
def should_end_interview(session_id: str) -> bool:
    """
    Determine if the interview should end based on question count.
    
    Args:
        session_id: The interview session identifier
        
    Returns:
        bool: True if interview should end, False otherwise
    """
    count = crud.get_question_count(session_id)
    return count >= Config.MAX_INTERVIEW_QUESTIONS


# List of all tools available to the LLM
interview_tools = [
    get_conversation_history,
    check_question_count,
    should_end_interview
]
