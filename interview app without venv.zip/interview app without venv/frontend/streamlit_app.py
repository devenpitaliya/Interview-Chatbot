"""
Streamlit frontend for the Interview Chatbot.
Provides a two-page interface: input form and chat interface.
"""
import streamlit as st
import requests
from typing import Dict, Any
import time


# Configuration
API_BASE_URL = "http://localhost:8000"


def init_session_state():
    """Initialize Streamlit session state variables."""
    if 'page' not in st.session_state:
        st.session_state.page = 'input'
    if 'session_id' not in st.session_state:
        st.session_state.session_id = None
    if 'username' not in st.session_state:
        st.session_state.username = ""
    if 'role' not in st.session_state:
        st.session_state.role = ""
    if 'chat_history' not in st.session_state:
        st.session_state.chat_history = []
    if 'interview_active' not in st.session_state:
        st.session_state.interview_active = True
    if 'question_count' not in st.session_state:
        st.session_state.question_count = 0


def create_session(username: str, role: str, description: str) -> Dict[str, Any]:
    """
    Create a new interview session via API.
    
    Args:
        username: Name of the interviewee
        role: Role being interviewed for
        description: Brief description
        
    Returns:
        dict: Session data
    """
    try:
        response = requests.post(
            f"{API_BASE_URL}/api/session/create",
            json={
                "username": username,
                "role": role,
                "description": description
            }
        )
        response.raise_for_status()
        return response.json()
    except Exception as e:
        st.error(f"Error creating session: {str(e)}")
        return None


def send_message(session_id: str, message: str) -> Dict[str, Any]:
    """
    Send a message to the chatbot via API.
    
    Args:
        session_id: Session identifier
        message: User message
        
    Returns:
        dict: Response data
    """
    try:
        response = requests.post(
            f"{API_BASE_URL}/api/chat",
            json={
                "session_id": session_id,
                "message": message
            }
        )
        response.raise_for_status()
        return response.json()
    except Exception as e:
        st.error(f"Error sending message: {str(e)}")
        return None


def get_conversation_history(session_id: str) -> list:
    """
    Get conversation history for a session.
    
    Args:
        session_id: Session identifier
        
    Returns:
        list: List of messages
    """
    try:
        response = requests.get(
            f"{API_BASE_URL}/api/session/{session_id}/history"
        )
        response.raise_for_status()
        return response.json()
    except Exception as e:
        return []


def input_form_page():
    """Render the input form page."""
    st.title("🎯 AI Interview Assistant")
    st.markdown("### Welcome! Let's get started with your interview.")
    
    st.markdown("---")
    
    # Input form
    with st.form("interview_form"):
        username = st.text_input(
            "Your Name *",
            placeholder="e.g., John Doe",
            help="Enter your full name"
        )
        
        role = st.text_input(
            "Interview Role *",
            placeholder="e.g., Senior Software Engineer, Data Scientist",
            help="The position you're interviewing for"
        )
        
        description = st.text_area(
            "Brief Description (Optional)",
            placeholder="e.g., Full-stack development role focusing on React and Python",
            help="Add any additional context about the interview",
            height=100
        )
        
        submitted = st.form_submit_button("Start Interview 🚀", use_container_width=True)
        
        if submitted:
            if not username or not role:
                st.error("⚠️ Please fill in all required fields (Name and Role)")
            else:
                # Create session
                with st.spinner("Setting up your interview..."):
                    session_data = create_session(username, role, description)
                    
                    if session_data:
                        st.session_state.session_id = session_data['session_id']
                        st.session_state.username = username
                        st.session_state.role = role
                        st.session_state.page = 'chat'
                        st.success("✅ Interview session created!")
                        time.sleep(0.5)
                        st.rerun()
    
    # Footer
    st.markdown("---")
    st.markdown(
        """
        <div style='text-align: center; color: #666; font-size: 0.9em;'>
            <p>💡 This is an AI-powered interview simulation. Be yourself and answer naturally!</p>
        </div>
        """,
        unsafe_allow_html=True
    )


def chat_interface_page():
    """Render the chat interface page."""
    st.title(f"🎤 Interview: {st.session_state.role}")
    st.markdown(f"**Candidate:** {st.session_state.username}")
    
    # Load conversation history on first load
    if not st.session_state.chat_history and st.session_state.session_id:
        history = get_conversation_history(st.session_state.session_id)
        for msg in history:
            st.session_state.chat_history.append({
                'role': msg['role'],
                'content': msg['content']
            })
    
    # Progress indicator
    col1, col2 = st.columns([3, 1])
    with col1:
        st.markdown(f"**Questions Asked:** {st.session_state.question_count}")
    with col2:
        if st.button("End Interview", type="secondary"):
            st.session_state.page = 'input'
            st.session_state.session_id = None
            st.session_state.chat_history = []
            st.session_state.interview_active = True
            st.session_state.question_count = 0
            st.rerun()
    
    st.markdown("---")
    
    # Chat history container
    chat_container = st.container()
    
    with chat_container:
        # Display chat history
        for msg in st.session_state.chat_history:
            if msg['role'] == 'user':
                with st.chat_message("user", avatar="👤"):
                    st.markdown(msg['content'])
            else:
                with st.chat_message("assistant", avatar="🤖"):
                    st.markdown(msg['content'])
    
    # Chat input
    if st.session_state.interview_active:
        user_input = st.chat_input("Type your response here...")
        
        if user_input:
            # Add user message to history
            st.session_state.chat_history.append({
                'role': 'user',
                'content': user_input
            })
            
            # Display user message immediately
            with chat_container:
                with st.chat_message("user", avatar="👤"):
                    st.markdown(user_input)
            
            # Send message to API
            with st.spinner("Interviewer is thinking..."):
                response_data = send_message(st.session_state.session_id, user_input)
                
                if response_data:
                    # Add assistant response to history
                    st.session_state.chat_history.append({
                        'role': 'assistant',
                        'content': response_data['response']
                    })
                    
                    # Update state
                    st.session_state.question_count = response_data['question_count']
                    st.session_state.interview_active = response_data['interview_active']
                    
                    # Display assistant response
                    with chat_container:
                        with st.chat_message("assistant", avatar="🤖"):
                            st.markdown(response_data['response'])
                    
                    st.rerun()
    else:
        # Check if interview was terminated early or completed normally
        if st.session_state.question_count < 10:
            st.info("👋 Interview ended. Thank you for your time!")
        else:
            st.info("✅ Interview completed! Thank you for your time.")
        
        if st.button("Start New Interview", use_container_width=True):
            st.session_state.page = 'input'
            st.session_state.session_id = None
            st.session_state.chat_history = []
            st.session_state.interview_active = True
            st.session_state.question_count = 0
            st.rerun()


def main():
    """Main application entry point."""
    # Page configuration
    st.set_page_config(
        page_title="AI Interview Assistant",
        page_icon="🎯",
        layout="wide",
        initial_sidebar_state="collapsed"
    )
    
    # Custom CSS
    st.markdown("""
        <style>
        .stApp {
            max-width: 1200px;
            margin: 0 auto;
        }
        .stButton>button {
            border-radius: 8px;
            font-weight: 600;
        }
        .stTextInput>div>div>input,
        .stTextArea>div>div>textarea {
            border-radius: 8px;
        }
        </style>
    """, unsafe_allow_html=True)
    
    # Initialize session state
    init_session_state()
    
    # Route to appropriate page
    if st.session_state.page == 'input':
        input_form_page()
    else:
        chat_interface_page()


if __name__ == "__main__":
    main()
